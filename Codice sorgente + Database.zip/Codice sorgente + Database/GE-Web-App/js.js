
          <script>          var ".$row["nome"]." = '".$row["nome"]."';
                            var ".$row["descrizione"]." = ".$row["ID"]."; 
          </script>