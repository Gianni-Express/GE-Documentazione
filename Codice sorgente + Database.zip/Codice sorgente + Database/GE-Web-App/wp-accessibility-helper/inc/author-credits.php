<?php $wah_author_credits = get_option('wah_author_credits'); ?>
<?php if($wah_author_credits) { ?>
    <div class="wah_plugin_credits">
        <a href="http://volkov.co.il" target="_blank">Created by Alex Volkov</a>
    </div>
<?php } ?>
