﻿ <?php                           if (session_status() === PHP_SESSION_NONE){
                            session_start();
                          }?> <!doctype html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title  -->
    <title>Gianni Express</title>

    <!-- Favicon  -->
      <link rel="icon" href="img/galleria/logo.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
<?php
                               
    ?>

    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner-grow" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>



    <?php
    if(isset($_SESSION["id"])){
    ?>



    <!-- Header Area -->
    <header class="header_area">

        <!-- Main Menu -->
        <div class="bigshop-main-menu">
            <div class="container">
                <div class="classy-nav-container breakpoint-off">
                    <nav class="classy-navbar" id="bigshopNav">

                        <!-- Nav Brand -->
                        <a href="index.php" class="nav-brand"><img style="width: 50px;height: 50px;" src="img/galleria/logo.png" alt="logo"></a>

                        <!-- Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">
                            <!-- Close -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="#">Catalogo</a>
                                        <ul class="dropdown">
                                            <li><a href="catalogo-dolce-1.php">Dolce</a></li>
                                            <li><a href="catalogo-salato-1.php">Salato</a></li>
                                            <li><a href="catalogo-bevande-1.php">Bevande</a></li>
                                        </ul>
                                    </li>
                                        
                                    <?php if(isset($_SESSION["id"])){ ?>
                                        <li><a href="carrello.php">Carrello</a></li>
                                    <?php } ?>

                                    <li><a href="about-us.php">About us</a></li>
                                </ul>
                            </div>

                        </div>


                    <?php if(isset($_SESSION["id"])){ ?>

                        <!-- Hero Meta -->
                        <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">

                            <!-- Account -->
                            <div class="account-area">
                                <div class="user-thumbnail">
                                    <a href="my-account.php"><img src="img/galleria/user1.jpg" alt=""></a>
                                    <!-- <img src="img/galleria/user1.jpg" alt=""> -->
                                </div>
                                <ul class="user-meta-dropdown">
                                    <li class="user-title"><span>Salve,</span>
                                        
                                        <?php
                                            
                                           
                                            
                                            include 'database/connessione.php';

                                            $sql = "SELECT * FROM users WHERE id=".$_SESSION['id']."";
                                            $result = $conn->query($sql);
                                            
                                            if ($result) {
                                                $row = $result->fetch_assoc();
                                                echo $row["nome"]." ".$row["cognome"];
                                            }
                                            
                                        ?>
                                    
                                    </li>
                                    <li><a href="utenti/logout.php"><i class="icofont-logout"></i> Logout</a></li>
                                </ul>
                            </div>
                        </div>

                    <?php }else{ ?>

                        <!-- Hero Meta -->
                        <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">
                            <a href="login.php" class="btn btn-dark mb-1"></i>LOGIN</a>
                        </div>

                    <?php } ?>


                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->




    <!-- Breadcumb Area -->
    <div class="breadcumb_area">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <h5>Carrello</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area -->


    <?php
                                        $totale_assoluto= 0;
                                        $sql = "SELECT u.id,p.nome, p.prezzo, pc.quantita, pc.quantita *p.prezzo as tot, pc.id as id_prod_carr 
                                        FROM users u 
                                        JOIN carrello c on c.id_utente =u.id 
                                        JOIN prodotto_carrello pc on pc.id_carrello =c.id 
                                        JOIN prodotti p on p.ID = pc.id_prodotto 
                                        WHERE c.id =".$_SESSION["id_carrello"]." and c.ordinato = 0"; // lettura dei dati nella tabella users
                                        $result_prodotto = $conn->query($sql);
                                        //echo $sql."<br>";                                                             
                                        if ($result_prodotto->num_rows > 0) {

                                            ?>
    <!-- Cart Area -->
    <div class="cart_area clearfix section_padding_50">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-12">
                    <div class="cart-table">
                        <div class="table-responsive">
                            <table class="table table-bordered mb-30">
                                <thead>
                                    <tr>
                                        <th scope="col"><i class="icofont-ui-delete"></i></th>
                                        <th scope="col">Prodotto</th>
                                        <th scope="col">Prezzo</th>
                                        <th scope="col">Totale</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                            // output data of each row
                                            while($row = $result_prodotto->fetch_assoc()) {
                                                  
                                                $prz= $row["prezzo"];
                                                $stamp = $row["quantita"].' x '.round($prz,2).'€';
                                                $przTot= round($row["tot"],2);
                                               // echo(round($prz,1));
                                                echo '<tr>
                                                    <th scope="row"><a href="carrello/remove_carrello.php?id_prod_carr='.$row["id_prod_carr"].'"><i class="icofont-close" ></i></a></th>
                                                    <td>'.$row["nome"].'</td>
                                                    <td>'.$stamp.'</td>
                                                    <td>'.$przTot.'</td>
                                                </tr>';
                                                $totale_assoluto = $totale_assoluto + $przTot;
                                            }
                                        
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--To be continued-->

               <div class="col-12 col-lg-5">
                    <div class="cart-total-area mb-30">
                        <h5 class="mb-3">Prezzo complessivo: <strong> <?php $_SESSION['totale_assoluto']=$totale_assoluto; echo $totale_assoluto." €";?></strong></h5>
                        <a href="./carrello/checkout.php" id="prenota" class="btn btn-primary d-block">Prenota</a>
                    </div>
                </div>
            </div>
        </div>
    </div> 
    <!-- Cart Area End -->

<?php
}else{
 echo '<br><br><br>'; 
echo '
    <!-- Popular Items Area -->
    <div class="popular_items_area home-3 section_padding_0_70">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="popular_section_heading mb-50 text-center">
                    <h5>Non hai nulla nel tuo carrello!</h5>
                </div>
            </div>
        </div>

';

    }
?>
<br><br>    
        <!-- Popular Items Area -->
        <div class="popular_items_area home-3 section_padding_0_70">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="popular_section_heading mb-50 text-center">
                        <h5>Prodotti più venduti</h5>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="popular_items_slides owl-carousel">

                        <!-- Single Popular Item -->
                        <div class="single_popular_item">
                            <div class="product_image">
                                <!-- Product Image -->
                                <img class="first_img" src="img/galleria/calzone2.jpg" alt="">

                                <!-- Add to cart 
                                <div class="product_add_to_cart">
                                    <a href="#">Acquista</a>
                                </div>
                                -->
                            </div>
                            <!-- Product Description -->
                            <div class="product_description">
                                <h5><a href="#">Calzone</a></h5>
                                <h6>€ 2,00</h6>
                            </div>
                        </div>

                        <!-- Single Popular Item -->
                        <div class="single_popular_item">
                            <div class="product_image">
                                <!-- Product Image -->
                                <img class="first_img" src="img/galleria/triangolino2.jpg" alt="">

                                <!-- Add to cart 
                                <div class="product_add_to_cart">
                                    <a href="#">Acquista</a>
                                </div>
                                -->
                            </div>
                            <!-- Product Description -->
                            <div class="product_description">
                                <h5><a href="#">Triangolino</a></h5>
                                <h6>€ 0,70</h6>
                            </div>
                        </div>

                        <!-- Single Popular Item -->
                        <div class="single_popular_item">
                            <div class="product_image">
                                <!-- Product Image -->
                                <img class="first_img" src="img/galleria/pizzetta2.jpg" alt="">

                                <!-- Add to cart 
                                <div class="product_add_to_cart">
                                    <a href="#">Acquista</a>
                                </div>
                                -->
                            </div>
                            <!-- Product Description -->
                            <div class="product_description">
                                <h5><a href="#">Pizzetta</a></h5>
                                <h6>€ 1,50</h6>
                            </div>
                        </div>

                        <!-- Single Popular Item -->
                        <div class="single_popular_item">
                            <div class="product_image">
                                <!-- Product Image -->
                                <img class="first_img" src="img/galleria/coca2.jpg" alt="">

                                <!-- Add to cart 
                                <div class="product_add_to_cart">
                                    <a href="#">Acquista</a>
                                </div>
                                -->
                            </div>
                            <!-- Product Description -->
                            <div class="product_description">
                                <h5><a href="#">Coca Cola</a></h5>
                                <h6>€ 1,10</h6>
                            </div>
                        </div>

                        <!-- Single Popular Item -->
                        <div class="single_popular_item">
                            <div class="product_image">
                                <!-- Product Image -->
                                <img class="first_img" src="img/galleria/cornetto2.jpg" alt="">

                                <!-- Add to cart 
                                <div class="product_add_to_cart">
                                    <a href="#">Acquista</a>
                                </div>
                                -->
                            </div>
                            <!-- Product Description -->
                            <div class="product_description">
                                <h5><a href="#">Cornetto</a></h5>
                                <h6>€ 0,70</h6>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Popular Items Area -->


<?php }else{ ?>

    <!-- Not Found Area -->
    <br><br><br><br>
    <section class="error_page text-center section_padding_100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-6">
                    <div class="not-found-text">
                        <h2 class="fa fa-close"></h2>
                        <h4 class="mb-3">Accesso negato</h4>
                        <h6 class="mb-3">Per poter accedere a questa sezione del sito bisogna essere registrati</h6>
                        <a href="../index.php" class="btn btn-primary mt-3">HOME</a>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="../login.php" class="btn btn-primary mt-3">LOGIN</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <br><br><br><br>
    <!-- Not Found Area End -->

<?php } ?>


    <!-- Footer Area -->
    <footer class="footer_area">
        <div class="container section_padding_50_0">
            <div class="row">

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6> - Navigazione - </h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="index.php"><i class="icofont-rounded-right"></i> Home <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="carrello.php"><i class="icofont-rounded-right"></i> Carrello <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="about-us.php"><i class="icofont-rounded-right"></i> About us <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6>- Catalogo -</h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="catalogo-dolce-1.php"><i class="icofont-rounded-right"></i> Dolce <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="catalogo-salato-1.php"><i class="icofont-rounded-right"></i> Salato <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="catalogo-bevande-1.php"><i class="icofont-rounded-right"></i> Bevande <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer_bottom_area">
            <div class="container">
                <div class="row align-items-center">
                    <!-- Copywrite -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite_text">
                            <p>Made with <i class="fa fa-heart" aria-hidden="true"></i> by Flore, Mari, Safi, Dedo, Botto</p>
                            <p>Progetto scolastico di: I.I.S. A. Avogadro di Torino</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/default/classy-nav.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/default/scrollup.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jarallax.min.js"></script>
    <script src="js/jarallax-video.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/default/active.js"></script>
    <script>

    
    </script>

</body>

</html>