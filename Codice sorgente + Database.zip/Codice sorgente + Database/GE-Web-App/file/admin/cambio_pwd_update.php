<?php
                
                if (session_status() === PHP_SESSION_NONE){
                    session_start();
                  }
    

//echo $_SESSION["sas"]." ".$_REQUEST["pwd0"]." ".$_REQUEST["pwd1"];



if ($_REQUEST["pwd0"] == $_REQUEST["pwd1"]) {
 
    include '../database/connessione.php';
    $salt = "SSERPXEINNAIG";
    $pass=crypt($_REQUEST["pwd1"],$salt);
    $sql = "UPDATE users SET pass='".$pass."' WHERE id=".$_SESSION["sas"];
    $result = $conn->query($sql);
    
                if ($result) {
                    echo "password cambiata";
                }else{
                    echo "errore".$conn->error;
                }
} else {
    # code...
}


session_destroy();
header("Refresh: 1 , url=../login.php");
?>