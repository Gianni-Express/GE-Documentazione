<?php
                    if (session_status() === PHP_SESSION_NONE){
                      session_start();
                    }         
$disp = $_REQUEST["disp"];

  $id = $_REQUEST["id"];
  //echo $descrizione;

    include '../database/connessione.php'; //include il collegamento 

    $sql = "UPDATE prodotti SET disponibilità=".$disp." WHERE ID=".$id;

    if ($conn->query($sql)) {
      //echo "New record created successfully";

      //$_SESSION["new_prodotto"] = $conn->insert_id;
      //include 'inserimento_prodotto_carrello.php';


     header("Refresh: 0 , url=".$_SERVER['HTTP_REFERER']."");


    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close(); 
?>