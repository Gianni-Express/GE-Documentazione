<?php

if (session_status() === PHP_SESSION_NONE){
  session_start();
}            


              $sql = "SELECT * FROM carrello"; // lettura dei dati nella tabella users
              $result_prodotto = $conn->query($sql);                                                 //per ottenere l'id con cui andare a strutturare il carrello
              //echo $sql."<br>";                                                             
              if ($result_prodotto->num_rows > 0) {
                // output data of each row
                    while($row = $result_prodotto->fetch_assoc()) {
                    
                          $id_carrello = $row["id"];
                              $SQL_insert= "INSERT INTO prodotto_carrello (`id`,`id_carrello`,`id_prodotto`,`quantita`) VALUES (NULL,$id_carrello,".$_SESSION['new_prodotto'].",0)";
                              echo "<br>".$SQL_insert."<br>";
                              $resuolt_prodotto_carrello = $conn->query($SQL_insert); 
                              if ($resuolt_prodotto_carrello) {
                                echo "ok +  ".$conn ->error."<br>";
                              }else{
                                echo $conn ->error;
                              }
                    }
              } else {
                echo "0 results";
              }
?>