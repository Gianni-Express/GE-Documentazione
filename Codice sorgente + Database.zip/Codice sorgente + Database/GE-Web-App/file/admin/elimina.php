

<?php

$id= $_GET["id"];
echo $id;   
        include '../database/connessione.php';
                
    $sql = "UPDATE prodotti set visual=1 WHERE ID=".$id;

    $select = $conn->query($sql);

    if ($select) {
        header("Refresh: 0, url=".$_SERVER['HTTP_REFERER']."");
    } else {
        echo "Eliminazione non andata a buon fine";
        header("Refresh: 1.6, url=".$_SERVER['HTTP_REFERER']."");
    }
    


?>