<?php
               
               if (session_status() === PHP_SESSION_NONE){
                session_start();
              }


  if ($_SESSION["role"] == "a" || $_SESSION["role"] == "s") {
    
    $path=null;

  

  $tipo = $_REQUEST["tipologia"];
  $costo = $_REQUEST["costo"];
  $nome = $_REQUEST["nome"]; 
  $energia = $_REQUEST["energia"];
  
  $descrizione = $_REQUEST["desc"];
  //$path = $_REQUEST["path"]; 

  //echo $_REQUEST["tipologia"];


  if(isset($_FILES["path"])){
 
    $path = $_FILES["path"]["name"];

    switch ($_REQUEST["tipologia"]) {
      case 'd':
        $target_dir = "./img/prodotti-dolci/";
        break;
      case 's':
        $target_dir = "./img/prodotti-salati/";
        break;
      case 'b':
        $target_dir = "./img/prodotti-bevande/";
        break;
    }


    $target_file = $target_dir . basename($_FILES["path"]["name"]);
  
    echo $target_file;

    // Select file type
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
  
    // Valid file extensions
    $extensions_arr = array("jpg","jpeg","png","gif");
  
    // Check extension
      if( in_array($imageFileType,$extensions_arr)){
        // Upload file
        move_uploaded_file($_FILES['path']['tmp_name'],$target_dir.$path);
    
      }
   
  }

  $nome_prod = str_replace(' ', '', $_REQUEST["nome"]);
  //echo $descrizione;

    include '../database/connessione.php'; //include il collegamento 

    $sql = "INSERT INTO prodotti (nome,descrizione,prezzo,TIPO,im,nome_prod,energia)";
    $sql .= "VALUES ('$nome','$descrizione','$costo','$tipo','$target_file','$nome_prod','$energia')";
      //echo $sql;
    if ($conn->query($sql)) {
      echo "New record created successfully";

      //$_SESSION["new_prodotto"] = $conn->insert_id;
      //include 'inserimento_prodotto_carrello.php';
      header("Refresh: 10 , url=../admin/inserimento.php");

          $last_id = $conn->insert_id;

      foreach($_POST['check_list'] as $id) {
        //zona di inserimento checkbox
        $sql = "INSERT INTO prodotti_ingredienti (`id`, `id_prod`, `id_ingrediente`) VALUES (NULL, ".$last_id.",".$id.") ";
            if ($conn->query($sql) === TRUE) {
            $flag=true;
            } else {
              $flag=false;
            }
          }
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }




  } else {
    echo 'you are not allowed to be there';
  }






    $conn->close(); 
?>
