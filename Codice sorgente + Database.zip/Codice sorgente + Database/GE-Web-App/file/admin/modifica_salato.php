 <?php                           if (session_status() === PHP_SESSION_NONE){
                            session_start();
                          }?> <!doctype html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title  -->
    <title>Gianni Express</title>

    <!-- Favicon  -->
      <link rel="icon" href="../img/galleria/logo.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="../style.css">

    <style>
        /* Chrome, Safari, Edge, Opera */
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
        }
        /* Firefox */
        input[type=number] {
        -moz-appearance:textfield;
        }
    </style>

</head>

<body>
<?php
                               
    ?>

    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner-grow" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>


    <?php
    if(isset($_SESSION["id"]) && $_SESSION["role"] == 'a'){
    include '../navbar.php';
    ?>


    <!-- Breadcumb Area -->
    <div class="breadcumb_area">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <h5>Modifica dei prodotti salati</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area -->

<br>

    <!-- Shop List Area -->
    <section class="shop_list_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-md-10">
                    <div class="shop_list_product_area">
                        <div class="row">

<?php


$sql = "SELECT * FROM prodotti p where p.TIPO='s' and p.visual = 0"; // lettura dei dati nella tabella users
$result_prodotto = $conn->query($sql);
//echo $sql."<br>";                                                             
if ($result_prodotto->num_rows > 0) {
    // output data of each row
    while($row = $result_prodotto->fetch_assoc()) {
        echo '
                            <!-- Single Product -->
                            <div class="col-12">
                                <div class="single-product-area mb-30">
                                    <div class="product_image">
                                        <!-- Product Image -->
                                        <img class="normal_img" src=".'.$row["im"].'" alt="">
                                    </div>

                                    <!-- Product Description -->
                                    <div class="product_description">

                                        <p class="brand_name">Salato</p>
                                        <form action="update_dati.php" method="POST">

                                            <input type="hidden" class="form-control" name="id" id="nome" value=" '.$row["ID"].'" readonly>
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="nome" id="nome" placeholder="Nome: '.$row["nome"].'" readonly>
                                                <br>
                                                <input type="number" style="width:40%;display:inline;" class="form-control" name="prezzo" id="prezzo" placeholder="Prezzo: '.$row["prezzo"].'€" readonly>
                                                &nbsp;&nbsp;
                                                <input type="number" style="width:40%;display:inline;" class="form-control" name="disp" id="disp" placeholder="'.$row["disponibilità"].' pezzi">
                                            </div>


                                            <span style="display:inline-block; width:80%;">
                                                    <input  style="margin: 5px; padding: 0px; display:inline; width:100px;" class="btn btn-primary fa" type="submit"  value="modifica">
                                                    <a      style="margin: 5px; padding: 13px; display:inline; width:100px;" class="btn btn-primary fa" href="./elimina.php?id='.$row["ID"].'">Elimina</a>
                                            </span>

                                        </form>
                                        <p class="product-short-desc"></p>

                                    </div>
                                </div>
                            </div>
';
                        }
                    }
                    
                    ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





<?php }else{ ?>

    <!-- Not Found Area -->
    <br><br><br><br>
    <section class="error_page text-center section_padding_100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-6">
                    <div class="not-found-text">
                        <h2 class="fa fa-close"></h2>
                        <h4 class="mb-3">Accesso negato</h4>
                        <h6 class="mb-3">Non si dispone dei permessi necessari per accedere a questa sezione</h6>
                        <a href="../index.php" class="btn btn-primary mt-3 ">HOME</a>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="../login.php" class="btn btn-primary mt-3">LOGIN</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <br><br><br><br>
    <!-- Not Found Area End -->

<?php } ?>


    <!-- Footer Area -->
    <footer class="footer_area">
        <div class="container section_padding_50_0">
            <div class="row">

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6> - Navigazione - </h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="super_admin.php"><i class="icofont-rounded-right"></i> Home <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="ordini.php"><i class="icofont-rounded-right"></i> Ordinazioni <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="inserimento.php"><i class="icofont-rounded-right"></i> Inserimento <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                    <div class="footer_heading mb-4">
                            <h6>- Modifiche -</h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="modifica_dolce.php"><i class="icofont-rounded-right"></i> Dolce <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="modifica_salato.php"><i class="icofont-rounded-right"></i> Salato <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="modifica_bevande.php"><i class="icofont-rounded-right"></i> Bevande <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer_bottom_area">
            <div class="container">
                <div class="row align-items-center">
                    <!-- Copywrite -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite_text">
                            <p>Made with <i class="fa fa-heart" aria-hidden="true"></i> by Flore, Mari, Safi, Dedo, Botto</p>
                            <p>Progetto scolastico di: I.I.S. A. Avogadro di Torino</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.easing.min.js"></script>
    <script src="../js/default/classy-nav.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/default/scrollup.js"></script>
    <script src="../js/waypoints.min.js"></script>
    <script src="../js/jquery.countdown.min.js"></script>
    <script src="../js/jquery.counterup.min.js"></script>
    <script src="../js/jquery-ui.min.js"></script>
    <script src="../js/jarallax.min.js"></script>
    <script src="../js/jarallax-video.min.js"></script>
    <script src="../js/jquery.magnific-popup.min.js"></script>
    <script src="../js/jquery.nice-select.min.js"></script>
    <script src="../js/wow.min.js"></script>
    <script src="../js/default/active.js"></script>

</body>

</html>
