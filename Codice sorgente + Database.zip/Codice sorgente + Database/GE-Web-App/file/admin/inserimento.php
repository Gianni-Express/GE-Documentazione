﻿ <?php                           if (session_status() === PHP_SESSION_NONE){
                            session_start();
                          }?> <!doctype html>
<html lang="it">

<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title  -->
    <title>Gianni Express</title>

    <!-- Favicon  -->
      <link rel="icon" href="../img/galleria/logo.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="../style.css">

</head>

<body>
<?php
                               
    ?>

    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner-grow" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>


    <?php
  if(isset($_SESSION["id"]) && $_SESSION["role"] == 'a'){
    ?>


    <!-- Header Area -->
    <header class="header_area">

        <!-- Main Menu -->
        <div class="bigshop-main-menu">
            <div class="container">
                <div class="classy-nav-container breakpoint-off">
                    <nav class="classy-navbar" id="bigshopNav">

                        <!-- Nav Brand -->
                        <a href="super_admin.php" class="nav-brand"><img style="width: 50px;height: 50px;" src="../img/galleria/logo.png" alt="logo"></a>

                        <!-- Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">
                            <!-- Close -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav -->
                            <div class="classynav">
                              <ul>
                                  <li><a href="super_admin.php">Home</a></li>
                                  <li><a href="#">Modifiche</a>
                                      <ul class="dropdown">
                                          <li><a href="modifica_dolce.php">Dolce</a></li>
                                          <li><a href="modifica_salato.php">Salato</a></li>
                                          <li><a href="modifica_bevande.php">Bevande</a></li>
                                      </ul>
                                  </li>
                                  <li><a href="ordini.php">Ordinazioni</a></li>
                                  <li><a href="inserimento.php">Inserimento</a></li>
                                  <li><a href="../about-us.php">About us</a></li>
                              </ul>
                            </div>

                        </div>


                    <?php if(isset($_SESSION["id"])){ ?>

                        <!-- Hero Meta -->
                        <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">

                            <!-- Account -->
                            <div class="account-area">
                                <div class="user-thumbnail">
                                    <a href="../my-account.php"><img src="../img/galleria/user1.jpg" alt=""></a>
                                    <!-- <img src="img/galleria/user1.jpg" alt=""> -->
                                </div>
                                <ul class="user-meta-dropdown">
                                    <li class="user-title"><span>Salve,</span>
                                        
                                        <?php
                                            
                                           
                                            
                                            include '../database/connessione.php';

                                            $sql = "SELECT * FROM users WHERE id=".$_SESSION['id']."";
                                            $result = $conn->query($sql);
                                            
                                            if ($result) {
                                                $row = $result->fetch_assoc();
                                                echo $row["nome"]." ".$row["cognome"];
                                            }
                                            
                                        ?>
                                    
                                    </li>
                                    <li><a href="../utenti/logout.php"><i class="icofont-logout"></i> Logout</a></li>
                                </ul>
                            </div>
                        </div>

                    <?php }else{ ?>

                        <!-- Hero Meta -->
                        <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">
                            <a href="../login.php" class="btn btn-dark mb-1"></i>LOGIN</a>
                        </div>

                    <?php } ?>


                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Breadcumb Area -->
    <div class="breadcumb_area">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <h5>Inserimento di un nuovo prodotto</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area -->

<br>

    <!-- Cart Area -->
    <div class="cart_area clearfix">
        <div class="container">
            <div class="row justify-content-between">

                <div class="col-12 col-lg-6">
                    <div class="cart-apply-coupon mb-30">
                        <!-- Form -->
                        <div class="coupon-form">
                            <form action="./insert_prodotto.php" method="POST" enctype="multipart/form-data" >
                            
                                <h5>Nome</h5>
                                <input type="text" class="form-control" name="nome" placeholder="Inserire il nome del prodotto" required>

                                <h5>Descrizione</h5>
                                <input type="text" class="form-control" name="desc" placeholder="Inserire una rapida descrizione del prodotto" required>

                                <h5>Prezzo</h5>
                                <input type="number" class="form-control qty-text" pattern="[0.10-5.00]*" inputmode="numeric" name="costo" step="0.10" min="0.10" max="5.00" placeholder="Inserire il prezzo del prodotto" required>

                                <h5>Tipologia</h5>
                                <select name="tipologia">
                                    <option value="s">Salato</option>
                                    <option value="d">Dolce</option>
                                    <option value="b">Bevanda</option>
                                </select><br><br>
                                
                                <h5>Calorie totali</h5>
                                <input type="number" class="form-control qty-text" pattern="[1-3000]*" inputmode="numeric" name="energia" step="1" min="0" max="3000" placeholder="Inserire il prezzo del prodotto" required>


                                <h5>Immagine visualizzata</h5>
                                <input type="file" class="form-control" id="path" name="path" placeholder="Inserire il percorso dell'immagine che verr&agrave; visualizzata" required>
                                <br>
<?php
                                    
                    $sql = "SELECT * FROM ingredienti ORDER BY nome"; // lettura dei dati nella tabella users
                    $result_prodotto = $conn->query($sql);
                    //echo $sql."<br>";                                                             
                    if ($result_prodotto->num_rows > 0) {
                        // output data of each row
                        while($row = $result_prodotto->fetch_assoc()) {
                        
                            echo '
                            <div class="form-check">
                                <div class="custom-control custom-checkbox mb-3 pl-1">
                                    <input class="form-check-input" type="checkbox" name="check_list[]"  value="'.$row["id"].'">
                                    <label>'.Ucwords($row["nome"]).'</label><br>
                                </div>
                            </div>
                            ';
                                
                        }
                    }
?>
                                <br>
                                <button type="submit" class="btn btn-primary">Caricare</button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            
        </div>
    </div>
    <!-- Cart Area End -->










<?php }else{ ?>

    <!-- Not Found Area -->
    <br><br><br><br>
    <section class="error_page text-center section_padding_100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-6">
                    <div class="not-found-text">
                        <h2 class="fa fa-close"></h2>
                        <h4 class="mb-3">Accesso negato</h4>
                        <h6 class="mb-3">Non si dispone dei permessi necessari per accedere a questa sezione</h6>
                        <a href="../index.php" class="btn btn-primary mt-3 ">HOME</a>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="../login.php" class="btn btn-primary mt-3">LOGIN</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <br><br><br><br>
    <!-- Not Found Area End -->

<?php } ?>


    <!-- Footer Area -->
    <footer class="footer_area">
        <div class="container section_padding_50_0">
            <div class="row">

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6> - Navigazione - </h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="super_admin.php"><i class="icofont-rounded-right"></i> Home <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="ordini.php"><i class="icofont-rounded-right"></i> Ordinazioni <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="inserimento.php"><i class="icofont-rounded-right"></i> Inserimento <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6>- Modifiche -</h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="modifica_dolce.php"><i class="icofont-rounded-right"></i> Dolce <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="modifica_salato.php"><i class="icofont-rounded-right"></i> Salato <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="modifica_bevande.php"><i class="icofont-rounded-right"></i> Bevande <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer_bottom_area">
            <div class="container">
                <div class="row align-items-center">
                    <!-- Copywrite -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite_text">
                            <p>Made with <i class="fa fa-heart" aria-hidden="true"></i> by Flore, Mari, Safi, Dedo, Botto</p>
                            <p>Progetto scolastico di: I.I.S. A. Avogadro di Torino</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.easing.min.js"></script>
    <script src="../js/default/classy-nav.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/default/scrollup.js"></script>
    <script src="../js/waypoints.min.js"></script>
    <script src="../js/jquery.countdown.min.js"></script>
    <script src="../js/jquery.counterup.min.js"></script>
    <script src="../js/jquery-ui.min.js"></script>
    <script src="../js/jarallax.min.js"></script>
    <script src="../js/jarallax-video.min.js"></script>
    <script src="../js/jquery.magnific-popup.min.js"></script>
    <script src="../js/jquery.nice-select.min.js"></script>
    <script src="../js/wow.min.js"></script>
    <script src="../js/default/active.js"></script>

</body>

</html>
