 <?php                           if (session_status() === PHP_SESSION_NONE){
                            session_start();
                          }?> <!doctype html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title  -->
    <title>Gianni Express</title>

    <!-- Favicon  -->
    <link rel="icon" href="../img/galleria/logo.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="../style.css">

</head>

<body>
<?php                            
//echo $_SESSION["id"];
include '../navbar.php';
?>
    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner-grow" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

<br><br><br><br>
<form action="./cambio_pwd.php" method="POST">
<p>inserisci l'email che hai utilizzato alla registrazione</p>
    <input type="email" name="email" id="">
    <input type="submit">
    
</form>

<br><br><br><br>

<br><br><br><br>




    <!-- Footer Area -->
    <footer class="footer_area">
        <div class="container section_padding_50_0">
            <div class="row">

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                    <div class="footer_heading mb-4">
                            <h6> - Navigazione - </h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="super_admin.php"><i class="icofont-rounded-right"></i> Home <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="ordini.php"><i class="icofont-rounded-right"></i> Ordinazioni <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="inserimento.php"><i class="icofont-rounded-right"></i> Inserimento <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                    <div class="footer_heading mb-4">
                            <h6>- Modifiche -</h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="modifica_dolce.php"><i class="icofont-rounded-right"></i> Dolce <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="modifica_salato.php"><i class="icofont-rounded-right"></i> Salato <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="modifica_bevande.php"><i class="icofont-rounded-right"></i> Bevande <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer_bottom_area">
            <div class="container">
                <div class="row align-items-center">
                    <!-- Copywrite -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite_text">
                            <p>Made with <i class="fa fa-heart" aria-hidden="true"></i> by Flore, Mari, Safi, Dedo, Botto</p>
                            <p>Progetto scolastico di: I.I.S. A. Avogadro di Torino</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.easing.min.js"></script>
    <script src="../js/default/classy-nav.min.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/default/scrollup.js"></script>
    <script src="../js/waypoints.min.js"></script>
    <script src="../js/jquery.countdown.min.js"></script>
    <script src="../js/jquery.counterup.min.js"></script>
    <script src="../js/jquery-ui.min.js"></script>
    <script src="../js/jarallax.min.js"></script>
    <script src="../js/jarallax-video.min.js"></script>
    <script src="../js/jquery.magnific-popup.min.js"></script>
    <script src="../js/jquery.nice-select.min.js"></script>
    <script src="../js/wow.min.js"></script>
    <script src="../js/default/active.js"></script>

</body>

</html>