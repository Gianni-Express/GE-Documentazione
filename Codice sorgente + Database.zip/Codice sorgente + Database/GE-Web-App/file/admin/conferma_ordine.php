<?php
                                           


                include '../database/connessione.php';
                
     $id_car = $_GET["id_conferma"];
                
                
        //echo $id_prod;
        $sql1 = "UPDATE carrello SET ordinato = 3 WHERE id=".$id_car.""; 
        //echo $sql1;
        //echo $sql1."<br>";     
        if ($result = $conn->query($sql1)) {
        //echo "Record updated successfully";
        header("Refresh: 0, url=".$_SERVER['HTTP_REFERER']."");
        } else {
        echo "Error updating record: " . $conn->error;
        }

?>