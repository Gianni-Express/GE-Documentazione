 <?php                           if (session_status() === PHP_SESSION_NONE){
                            session_start();
                          }?> <!doctype html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="css.css">
</head>
<body id="body">

<?php

  //CONNESSIONE DB
  $host = "localhost";
  $username = "gianni";
  $password = "gianni";
  $db_nome = "my_gianniexpress";

  $conn = new mysqli($host, $username, $password, $db_nome); 

  if ($conn->connect_error) {
    echo "Impossibile connettersi al server: " . $conn->connect_error . "\n";    
    exit; 
  }

?>

</body>

</html>