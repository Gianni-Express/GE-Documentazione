<?php
           if (session_status() === PHP_SESSION_NONE){
                session_start();
              }                

if(isset($_SESSION["id"]) && isset($_SESSION["id_carrello"])){

    $id_prod_carr = $_GET["id_prod_carr"];

    include '../database/connessione.php';

    $sql1 = "DELETE FROM prodotto_carrello WHERE prodotto_carrello.id = ".$id_prod_carr; 
                                        //echo $sql1."<br>"; 
                                        
                                        //echo $sql1;
                                        if ($resultdd = $conn->query($sql1)) {
                                        //echo "Record updated successfully";
                                        header("Refresh: 0, url=".$_SERVER['HTTP_REFERER']."");
                                        } else {
                                                echo "Error updating record: " . $conn->error;
                                        }
}



?>