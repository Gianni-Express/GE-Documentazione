<?php

if (session_status() === PHP_SESSION_NONE){
    session_start();
  }

    if (isset($_SESSION["id_carrello"])) {

                    //echo $_SESSION['totale_assoluto'];
                  
                include '../database/connessione.php';
                //$orario = date("Y-m-d H:i:s");
                //echo $_SESSION['id'].' '.$_SESSION['id_carrello'];


                sleep(0);
                $flag = true;
                $sql = "SELECT c.id, p.ID,pc.quantita,p.disponibilità FROM carrello c, prodotto_carrello pc, prodotti p
                 WHERE c.id = pc.id_carrello and pc.id_prodotto= p.ID and c.id=".$_SESSION["id_carrello"];
                 //unset($_SESSION['id_carrello']);
                 //echo $sql; 
                 $select = $conn->query($sql);

                 while($row = $select->fetch_assoc()) {

                      if ($row["quantita"] <= $row["disponibilità"]) {
                    
                          if($flag){  
                          $flag = true;
                          }
                      }else{
                      $flag = false;
                          // echo $row["ID"].' '.$row["quantita"].' '.$row["disponibilità"];
                      }


                  }



            if($flag){
               
                $sql = "UPDATE carrello 
                SET ordinato=2, costo_finale=".$_SESSION["totale_assoluto"].", orario=curdate()
                 WHERE id=".$_SESSION["id_carrello"];
                 
                 //echo $sql; 
                if ($conn->query($sql) === TRUE) {

                                    $sql = "SELECT c.id, p.ID,pc.quantita,p.disponibilità FROM carrello c, prodotto_carrello pc, prodotti p
                                    WHERE c.id = pc.id_carrello and pc.id_prodotto= p.ID and c.id=".$_SESSION["id_carrello"];
                                    //unset($_SESSION['id_carrello']);
                                    //echo $sql; 
                                    $select = $conn->query($sql);
                
                                    while($row = $select->fetch_assoc()) {

                                    $sas = $row["disponibilità"] - $row["quantita"];
                
                                    $sql = 'UPDATE prodotti set disponibilità ='.$sas.' where ID='.$row["ID"];
                                    
                                    if ($resultdd = $conn->query($sql)) {
                                    //echo "Record updated successfully";
                                        echo "ok";
                                    } else {
                                            echo "Error updating record: " . $conn->error;
                                    } 
                
                                    }


                        unset($_SESSION['id_carrello']);
                        unset($_SESSION['totale_assoluto']);
                        include '../utenti/insert_carrello.php';
                        $_SESSION['id_carrello'] = $conn->insert_id;
                        header("Refresh: 10 , url=../index.php");

                } else {
                  echo "Error updating record: " . $conn->error;
                }

            }else{
                echo "Alcuni sei prodotti non sono attualmente disponibili";

                header("Refresh: 0, url=".$_SERVER['HTTP_REFERER']."");
            }




    } else {
        echo "devi prima loggarti";
        header("Refresh: 0 , url=../login.php");
    }
    

?>