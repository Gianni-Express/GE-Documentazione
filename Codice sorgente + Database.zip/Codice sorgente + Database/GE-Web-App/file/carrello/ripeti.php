<?php
                                           
                                           if (session_status() === PHP_SESSION_NONE){
                                                session_start();
                                              }

include '../database/connessione.php';

                $id_carr = $_GET["id"];
                

                            $sql1 = "SELECT * FROM prodotto_carrello pc, prodotti p
                            WHERE pc.id_carrello=".$id_carr." and p.ID = pc.id_prodotto";

                                $result_prodotto = $conn->query($sql1);
                                $_SESSION["totale_assoluto"] = 0;
                                if ($result_prodotto->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result_prodotto->fetch_assoc()) {

                                        $sql1 = "INSERT INTO prodotto_carrello(`id_prodotto`, `id_carrello`,`quantita`) VALUES (".$row["id_prodotto"].",".$_SESSION["id_carrello"].",".$row["quantita"].")"; 
                                        echo $sql1;
                                        if ($resultdd = $conn->query($sql1)) {
                                                        $_SESSION["totale_assoluto"] = $_SESSION["totale_assoluto"] + ($row["prezzo"] * $row["quantita"]);
                                            } else {
                                                    echo "Error updating record: " . $conn->error;
                                            }
                                    
                                    }
                                    include "include_checkout.php";


        }else{
                echo "error";
        }


?>