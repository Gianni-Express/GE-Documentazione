<?php
                                           
                                           if (session_status() === PHP_SESSION_NONE){
                                                session_start();
                                              }

include '../database/connessione.php';
include './select_carrello.php';

                $id_prod = $_GET["id_aggiungere"];
                $quantita = $_GET["quantita"];

                sleep(0);

                $sql = 'SELECT quantita FROM prodotto_carrello WHERE id_prodotto = '.$id_prod.' and id_carrello='.$_SESSION["id_carrello"];
                //echo $sql;
                $result = $conn->query($sql);
                
                //echo $result->num_rows;
                //echo $conn->error;
                //echo $row["quantita"];
                if ($result->num_rows < 1) {


                                $sql = 'SELECT * FROM prodotti WHERE ID='.$id_prod;
                                $result = $conn->query($sql);
                                //verifica attuale disponibilità
                                $row = $result->fetch_assoc();
                                if ($row["disponibilità"] >= $quantita) {
                                        
                                $sql1 = "INSERT INTO prodotto_carrello(`id_prodotto`, `id_carrello`,`quantita`) VALUES (".$id_prod.",".$_SESSION["id_carrello"].",$quantita)"; 
                                
                                if ($resultdd = $conn->query($sql1)) {
                                //echo "Record updated successfully";
                                header("Refresh: 0, url=".$_SERVER['HTTP_REFERER']."");
                                } else {
                                        echo "Error updating record: " . $conn->error;
                                } 
                        }else{
                                header("Refresh: 0, url=".$_SERVER['HTTP_REFERER']."");
                                $message = "Gianni non ha abbastanzanza prodotti di quello che hai chiesto";
                                        echo "<script type='text/javascript'>alert('$message');</script>";
                        }




        }else{
                $row = $result->fetch_assoc();
              //  echo $row["quantita"];
                $quantita = $quantita + $row["quantita"];

                $sql = 'SELECT * FROM prodotti WHERE ID='.$id_prod;
                $result2 = $conn->query($sql);
                $row2 = $result2->fetch_assoc();
                if ($row2["disponibilità"] >= $quantita) {


                $sql1 = "UPDATE prodotto_carrello SET quantita=".$quantita." WHERE id_prodotto=".$id_prod." and id_carrello=".$_SESSION["id_carrello"] ; 
                
                if ($resultdd = $conn->query($sql1)) {
                //echo "Record updated successfully";
                header("Refresh: 0, url=".$_SERVER['HTTP_REFERER']."");
                } else {
                        echo "Error updating record: " . $conn->error;
                }
            }else{
                header("Refresh: 0, url=".$_SERVER['HTTP_REFERER']."");
                $message = "Gianni non ha abbastanzanza prodotti di quello che hai chiesto";
                        echo "<script type='text/javascript'>alert('$message');</script>";
            }

        }
?>