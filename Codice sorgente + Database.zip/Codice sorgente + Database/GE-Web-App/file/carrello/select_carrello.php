<?php
            
            if (session_status() === PHP_SESSION_NONE){
                session_start();
              }

include '../database/connessione.php';
$sql = "SELECT c.id FROM users u
        JOIN carrello c on c.id_utente =".$_SESSION["id"]." 
        WHERE c.ordinato = 0"; // lettura dei dati nella tabella users
                    $result_prodotto = $conn->query($sql);                                                 //per ottenere l'id con cui andare a strutturare il carrello
                    //echo $sql."<br>";                                                             
                    if ($result_prodotto->num_rows > 0) {
                        // output data of each row
                            while($row = $result_prodotto->fetch_assoc()) {
                    //echo $row["id"];
                            $_SESSION["id_carrello"] = $row["id"];
                        }
                    }else{
                        echo "errore + ".$sql." <br> + ".$_SESSION["id"]."<br>" ;
                    }
?>








