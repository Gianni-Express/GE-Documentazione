<?php


    if (isset($_SESSION["id"])) {
        
            if ($_SESSION["role"] == "a" || $_SESSION["role"] == "s" ) {
                ?>
                <!-- Header Area -->
                <header class="header_area">
            
                    <!-- Main Menu -->
                    <div class="bigshop-main-menu">
                        <div class="container">
                            <div class="classy-nav-container breakpoint-off">
                                <nav class="classy-navbar" id="bigshopNav">
            
                                    <!-- Nav Brand -->
                                    <a href="super_admin.php" class="nav-brand"><img style="width: 50px;height: 50px;" src="../img/galleria/logo.png" alt="logo"></a>
            
                                    <!-- Toggler -->
                                    <div class="classy-navbar-toggler">
                                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                                    </div>
            
                                    <!-- Menu -->
                                    <div class="classy-menu">
                                        <!-- Close -->
                                        <div class="classycloseIcon">
                                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                                        </div>
            
                                        <!-- Nav -->
                                        <div class="classynav">
                                            <ul>
                                                <li><a href="super_admin.php">Home</a></li>
                                                <li><a href="#">Modifiche</a>
                                                    <ul class="dropdown">
                                                        <li><a href="modifica_dolce.php">Dolce</a></li>
                                                        <li><a href="modifica_salato.php">Salato</a></li>
                                                        <li><a href="modifica_bevande.php">Bevande</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="ordini.php">Ordinazioni</a></li>
                                                <li><a href="inserimento.php">Inserimento</a></li>
                                               
                                            </ul>
                                        </div>
            
                                    </div>
            
                                        <!-- Hero Meta -->
                                        <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">
                                            <!-- Account -->
                                            <div class="account-area">
                                                <div class="user-thumbnail">
                                                    <a href="../my-account.php"><img src="../img/galleria/user1.jpg" alt=""></a>
                                                    <!-- <img src="img/galleria/user1.jpg" alt=""> -->
                                                </div>
                                                <ul class="user-meta-dropdown">
                                                    <li class="user-title"><span>Salve,</span>
                                                
    
                                                <?php
                                                    
                                                    include '../database/connessione.php';
                                                    $sql = "SELECT * FROM users WHERE id=".$_SESSION['id']."";
                                                    $result = $conn->query($sql);
                                                    if ($result) {
                                                        $row = $result->fetch_assoc();
                                                        echo $row["nome"]." ".$row["cognome"];
                                                    }else{
                                                        echo $conn->error;
                                                        echo '0';
                                                    }


                                                ?>
                                                    
            
                                                    </li>
                                                    <li><a href="../utenti/logout.php"><i class="icofont-logout"></i> Logout</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </header>
                <!-- Header Area End -->

                <?php 
            } else {
                ?>
                
    <!-- Header Area -->
    <header class="header_area">

        <!-- Main Menu -->
        <div class="bigshop-main-menu">
            <div class="container">
                <div class="classy-nav-container breakpoint-off">
                    <nav class="classy-navbar" id="bigshopNav">

                        <!-- Nav Brand -->
                        <a href="index.php" class="nav-brand"><img style="width: 50px;height: 50px;" src="img/galleria/logo.png" alt="logo"></a>

                        <!-- Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">
                            <!-- Close -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="#">Catalogo</a>
                                        <ul class="dropdown">
                                            <li><a href="catalogo-dolce-1.php">Dolce</a></li>
                                            <li><a href="catalogo-salato-1.php">Salato</a></li>
                                            <li><a href="catalogo-bevande-1.php">Bevande</a></li>
                                        </ul>
                                    </li>

                                    
                                        
                                    <li><a href="carrello.php">Carrello</a></li>
                                    

                                   

                                    <li><a href="about-us.php">About us</a></li>
                                </ul>
                            </div>

                        </div>


                        <!-- Hero Meta -->
                            <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">
                                <!-- Account -->
                                <div class="account-area">
                                    <div class="user-thumbnail">
                                        <a href="my-account.php"><img src="img/galleria/user1.jpg" alt=""></a>
                                        <!-- <img src="img/galleria/user1.jpg" alt=""> -->
                                    </div>
                                    <ul class="user-meta-dropdown">
                                        <li class="user-title"><span>Salve,</span>
                                            <?php
                                                include 'database/connessione.php';
                                                $sql = "SELECT * FROM users WHERE id=".$_SESSION['id']."";
                                                $result = $conn->query($sql);
                                                if ($result) {
                                                    $row = $result->fetch_assoc();
                                                    echo $row["nome"]." ".$row["cognome"];
                                                }else{
                                                    echo $conn->error;
                                                    echo '0';
                                                }
                                            ?>
                                        </li>
                                        <li><a href="utenti/logout.php"><i class="icofont-logout"></i> Logout</a></li>
                                    </ul>
                                </div>
                            </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <?php       
            }
            

    } else {
        ?>
           
        <!-- Header Area -->
        <header class="header_area">
    
            <!-- Main Menu -->
            <div class="bigshop-main-menu">
                <div class="container">
                    <div class="classy-nav-container breakpoint-off">
                        <nav class="classy-navbar" id="bigshopNav">
    
                            <!-- Nav Brand -->
                            <a href="index.php" class="nav-brand"><img style="width: 50px;height: 50px;" src="img/galleria/logo.png" alt="logo"></a>
    
                            <!-- Toggler -->
                            <div class="classy-navbar-toggler">
                                <span class="navbarToggler"><span></span><span></span><span></span></span>
                            </div>
    
                            <!-- Menu -->
                            <div class="classy-menu">
                                <!-- Close -->
                                <div class="classycloseIcon">
                                    <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                                </div>
    
                                <!-- Nav -->
                                <div class="classynav">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="#">Catalogo</a>
                                            <ul class="dropdown">
                                                <li><a href="catalogo-dolce-1.php">Dolce</a></li>
                                                <li><a href="catalogo-salato-1.php">Salato</a></li>
                                                <li><a href="catalogo-bevande-1.php">Bevande</a></li>
                                            </ul>
                                        </li>
    
                                        
                                            
                                        
                                        
    
                                       
    
                                        <li><a href="about-us.php">About us</a></li>
                                    </ul>
                                </div>
    
                            </div>
    
    
                            <!-- Hero Meta -->
                            <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">
                                             <a href="login.php" class="btn btn-dark mb-1">LOGIN</a>
                                        </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <?php    

    }

?>