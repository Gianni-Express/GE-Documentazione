﻿ <?php                           if (session_status() === PHP_SESSION_NONE){
                            session_start();
                          }?> <!doctype html>
<html lang="it">
<?php                            
include './database/connessione.php'; ?>
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <style>
        /* Chrome, Safari, Edge, Opera */
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
        }
        /* Firefox */
        input[type=number] {
        -moz-appearance:textfield;
        }
    </style>

    <!-- Title  -->
    <title>Gianni Express</title>

    <!-- Favicon  -->
      <link rel="icon" href="img/galleria/logo.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner-grow" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <!-- Header Area -->
    <header class="header_area">

        <!-- Main Menu -->
        <div class="bigshop-main-menu">
            <div class="container">
                <div class="classy-nav-container breakpoint-off">
                    <nav class="classy-navbar" id="bigshopNav">

                        <!-- Nav Brand -->
                        <a href="index.php" class="nav-brand"><img style="width: 50px;height: 50px;" src="img/galleria/logo.png" alt="logo"></a>

                        <!-- Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">
                            <!-- Close -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="#">Catalogo</a>
                                        <ul class="dropdown">
                                            <li><a href="catalogo-dolce-1.php">Dolce</a></li>
                                            <li><a href="catalogo-salato-1.php">Salato</a></li>
                                            <li><a href="catalogo-bevande-1.php">Bevande</a></li>
                                        </ul>
                                    </li>
                                    
                                    <?php if(isset($_SESSION["id"])){ ?>
                                        <li><a href="carrello.php">Carrello</a></li>
                                    <?php } ?>

                                    <li><a href="about-us.php">About us</a></li>
                                </ul>
                            </div>

                        </div>

                        
                        <?php if(isset($_SESSION["id"])){ ?>
                            <!-- Hero Meta -->
                            <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">
                                <!-- Account -->
                                <div class="account-area">
                                    <div class="user-thumbnail">
                                        <a href="my-account.php"><img src="img/galleria/user1.jpg" alt=""></a>
                                        <!-- <img src="img/galleria/user1.jpg" alt=""> -->
                                    </div>
                                    <ul class="user-meta-dropdown">
                                        <li class="user-title"><span>Salve,</span>
                                            <?php
                                                include 'database/connessione.php';
                                                $sql = "SELECT * FROM users WHERE id=".$_SESSION['id']."";
                                                $result = $conn->query($sql);
                                                if ($result) {
                                                    $row = $result->fetch_assoc();
                                                    echo $row["nome"]." ".$row["cognome"];
                                                }else{
                                                    echo $conn->error;
                                                    echo '0';
                                                }
                                            ?>
                                        </li>
                                        <li><a href="utenti/logout.php"><i class="icofont-logout"></i> Logout</a></li>
                                    </ul>
                                </div>
                            </div>
                        <?php }else{ ?>
                            <!-- Hero Meta -->
                            <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">
                                <a href="login.php" class="btn btn-dark mb-1">LOGIN</a>
                            </div>
                        <?php } ?>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Breadcumb Area -->
    <div class="breadcumb_area">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <h5>Catalogo salato</h5>
                        <?php 
                                if(isset($_SESSION["id_carrello"])){

                                    $totale_assoluto= 0;
                                    $sql = "SELECT u.id,p.nome, p.prezzo, pc.quantita, pc.quantita *p.prezzo as tot 
                                    FROM users u 
                                    JOIN carrello c on c.id_utente =u.id 
                                    JOIN prodotto_carrello pc on pc.id_carrello =c.id 
                                    JOIN prodotti p on p.ID = pc.id_prodotto 
                                    WHERE pc.quantita > 0 and c.id =".$_SESSION["id_carrello"]." and c.ordinato = 0"; // lettura dei dati nella tabella users
                                    $result_prodotto = $conn->query($sql);
                                    //echo $sql."<br>";                                                             
                                    if ($result_prodotto->num_rows > 0) {
                                        // output data of each row
                                        while($row = $result_prodotto->fetch_assoc()) {
                                            
                                           
                                            $prz= $row["prezzo"];
                                            $przTot= round($row["tot"],2);
                                            $totale_assoluto = $totale_assoluto + $przTot;
                                        }
                                    }

                                    echo "Prezzo complessivo ".$totale_assoluto."€";
                            }
                        ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area -->

    <br>

    <!-- Shop List Area -->
    <section class="shop_list_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-md-10">

                    

                    <div class="shop_list_product_area">
                        <div class="row">

            <?php

            include './database/connessione.php';


                $sql = "SELECT * FROM prodotti WHERE tipo='s' and visual = 0 order by prezzo DESC";
            $result = $conn->query($sql);
            $flag=false;
                if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {

                        if (isset($_SESSION["id"])) {
                
                            if($row["disponibilità"] > 0){
                                echo "
                        
                     
                                <!-- Single Product -->
                                <div class='col-12'>
                                    <div class='single-product-area mb-30'>
                                        <div class='product_image'>
                                            <!-- Product Image -->
                                            <img class='normal_img' src='".$row["im"]."' alt=''>
                                        </div>
                        
                                        <!-- Product Description -->
                                        <div class='product_description'>
                              
                                        <script>    var ".$row["nome_prod"]." = '".$row["nome_prod"]."';
                                        var ".$row["nome_prod"]."_".$row["TIPO"]." = ".$row["ID"]."; 
                                        //console.log('var='+".$row["TIPO"].");</script>
                
                                            <!-- Add to cart -->
                                            <div class='product_add_to_cart'>
                                                <a style='cursor: pointer;' onclick='add(".$row["nome"].",".$row["nome"]."_".$row["TIPO"].")' ><i class='icofont-shopping-cart'></i> Aggiungi al carrello</a>
                                            </div>
                        
                                            <!-- Quick View -->
                                            <div class='product_quick_view'>
                                                <a href='#' style='cursor: default;' data-toggle='modal' data-target='#quickview'><i class='icofont-eye-alt'></i> Disponibile - ".$row["disponibilità"]."</a>
                                            </div>
                        
                                            <p class='brand_name'>Dolce</p>
                                                                
                                            <h5 style='margin:0px'>
                                            <span style='display:inline;'>
                                                ".$row["nome"]." - €".$row['prezzo']."
                                                <a style='display:inline;' href='allergeno.php?id=".$row["ID"]."' target='_blank'>
                                                    <img style='display:inline;width:30px;height:30px;' src='./img/galleria/info.jpg' alt=''>
                                                </a>
                                            </span>
                                        </h5>
                                        <button type='button' onclick='less(".$row["nome_prod"].")'  class='bigshop-label bigshop-label-pill mb-1 btn-dark' style='height:30px;background-color: rgb(8, 8, 43) !important;'>-</button>
                                        <input class='form-control' id='".$row["nome_prod"]."' style='display:inline;width:50px;height:30px;' type='number' name='".$row["nome"]."' min='1' max='10'  value='1' readonly>
                                        <button type='button' onclick='more(".$row["nome_prod"].")' class='bigshop-label bigshop-label-pill mb-1 btn-dark' style='height:30px;background-color: rgb(8, 8, 43) !important;'>+</button>
                    
                                        </div>
                                    </div>
                                </div>";
                            }else{
                                echo "
                        
                     
                        <!-- Single Product -->
                        <div class='col-12'>
                            <div class='single-product-area mb-30'>
                                <div class='product_image'>
                                    <!-- Product Image -->
                                    <img class='normal_img' src='".$row["im"]."' alt=''>
                                </div>
                
                                <!-- Product Description -->
                                <div class='product_description'>
                      
                                <script>    var ".$row["nome_prod"]." = '".$row["nome_prod"]."';
                                var ".$row["nome_prod"]."_".$row["TIPO"]." = ".$row["ID"]."; 
                                //console.log('var='+".$row["TIPO"].");</script>
        
                                    <!-- Add to cart -->
                                    <div class='product_add_to_cart'>
                                        <a style='cursor: pointer;' ><i class='icofont-shopping-cart'></i> Sorry :(</a>
                                    </div>
                
                                    <!-- Quick View -->
                                    <div class='product_quick_view'>
                                    <a href='' data-toggle='' data-target='' style='background-color: red;'><i class='icofont-eye-alt'></i> Prodotto non disponibile</a>
                                    </div>
                
                                    <p class='brand_name'>Salato</p>
                                                        
                                    <h5 style='margin:0px'>
                                    <span style='display:inline;'>
                                        ".$row["nome"]." - €".$row['prezzo']."
                                        <a style='display:inline;' href='allergeno.php?id=".$row["ID"]."' target='_blank'>
                                            <img style='display:inline;width:30px;height:30px;' src='./img/galleria/info.jpg' alt=''>
                                        </a>
                                    </span>
                                </h5>
                                <button type='button' onclick='less(".$row["nome_prod"].")'  class='bigshop-label bigshop-label-pill mb-1 btn-dark' style='height:30px;background-color: rgb(8, 8, 43) !important;'>-</button>
                                <input class='form-control' id='".$row["nome_prod"]."' style='display:inline;width:50px;height:30px;' type='number' name='".$row["nome"]."' min='1' max='10'  value='1' readonly>
                                <button type='button' onclick='more(".$row["nome_prod"].")' class='bigshop-label bigshop-label-pill mb-1 btn-dark' style='height:30px;background-color: rgb(8, 8, 43) !important;'>+</button>
            
                                </div>
                            </div>
                        </div>";
                            }
        
        
                        
                        } else {
                            echo "<!-- Single Product -->
                            <div class='col-12'>
                                <div class='single-product-area mb-30'>
                                    <div class='product_image'>
                                        <!-- Product Image -->
                                        <img class='normal_img' src='".$row["im"]."' alt=''>
                                    </div>
                    
                                    <!-- Product Description -->
                                    <div class='product_description'>
                                        <!-- Add to cart -->
                                        <div class='product_add_to_cart'>
                                            <a style='cursor: pointer;' href='./login.php'><i class='icofont-shopping-cart'></i> Login</a>
                                        </div>
                    
                                        <!-- Quick View -->
                                        <div class='product_quick_view'>
                                            <a href='#' style='cursor: default;' data-toggle='modal' data-target='#quickview'><i class='icofont-eye-alt'></i> Disponibile</a>
                                        </div>
                    
                                        <p class='brand_name'>Prodotto salato</p>
                    
                                        <h5 style='margin:0px'>
                                        <span style='display:inline;'>
                                            ".$row["nome"]." - €".$row['prezzo']."
                                            <a style='display:inline;' href='allergeno.php?id=".$row["ID"]."' target='_blank'>
                                                <img style='display:inline;width:30px;height:30px;' src='./img/galleria/info.jpg' alt=''>
                                            </a>
                                        </span>
                                        </h5>
                                    
                                    <br>
                                        <p class='product-short-desc'> </p>
                    
                                    </div>
                                </div>
                            </div>";
                        }


                    }         
            }
            ?>
                    <!-- Shop Pagination Area -->

                </div>
            </div>
        </div>
    </section>
    <!-- Shop List Area -->

    <br><br>

    <!-- Footer Area -->
    <footer class="footer_area">
        <div class="container section_padding_50_0">
            <div class="row">

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6> - Navigazione - </h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="index.php"><i class="icofont-rounded-right"></i> Home <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="carrello.php"><i class="icofont-rounded-right"></i> Carrello <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="about-us.php"><i class="icofont-rounded-right"></i> About us <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6>- Catalogo -</h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="catalogo-dolce-1.php"><i class="icofont-rounded-right"></i> Dolce <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="catalogo-salato-1.php"><i class="icofont-rounded-right"></i> Salato <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="catalogo-bevande-1.php"><i class="icofont-rounded-right"></i> Bevande <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer_bottom_area">
            <div class="container">
                <div class="row align-items-center">
                    <!-- Copywrite -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite_text">
                            <p>Made with <i class="fa fa-heart" aria-hidden="true"></i> by Flore, Mari, Safi, Dedo, Botto</p>
                            <p>Progetto scolastico di: I.I.S. A. Avogadro di Torino</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/default/classy-nav.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/default/scrollup.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jarallax.min.js"></script>
    <script src="js/jarallax-video.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/default/active.js"></script>



    <script>
function less(id){
    //console.log(id);
    var element = document.getElementById(id);
    var value = element.value;
        if(value >= 2){

            value--;
            element.value = value;

        }
}

function more(id){
    //console.log(id);
    var element = document.getElementById(id);
    var value = element.value;
        if(value >= 10){

            console.log(
                "sas"
            );

        }else{
            value++;
            element.value = value;
        }
    }



function add(nome,ID_PRODOTTO){

    //console.log(document.getElementById(nome).value);
    //console.log(ID_PRODOTTO);
        var id_agg = ID_PRODOTTO;
        var q = document.getElementById(nome).value;
        window.location.replace("carrello/add_carrello.php?id_aggiungere="+id_agg+"&quantita="+q);

}



</script>



</body>

</html>