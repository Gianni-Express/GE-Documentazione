<?php
session_start();
?>
<!doctype html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title  -->
    <title>Gianni Express</title>

    <!-- Favicon  -->
      <link rel="icon" href="img/galleria/logo.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner-grow" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <!-- Header Area -->
    <header class="header_area">

        <!-- Main Menu -->
        <div class="bigshop-main-menu">
            <div class="container">
                <div class="classy-nav-container breakpoint-off">
                    <nav class="classy-navbar" id="bigshopNav">

                        <!-- Nav Brand -->
                        <a href="index.php" class="nav-brand"><img style="width: 50px;height: 50px;" src="img/galleria/logo.png" alt="logo"></a>

                        <!-- Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">
                            <!-- Close -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="#">Catalogo</a>
                                        <ul class="dropdown">
                                            <li><a href="catalogo-dolce-1.php">Dolce</a></li>
                                            <li><a href="catalogo-salato-1.php">Salato</a></li>
                                            <li><a href="catalogo-bevande-1.php">Bevande</a></li>
                                        </ul>
                                    </li>
                                    
                                    <?php if(isset($_SESSION["id"])){ ?>
                                        <li><a href="carrello.php">Carrello</a></li>
                                    <?php } ?>

                                    <li><a href="about-us.php">About us</a></li>
                                </ul>
                            </div>
                            
                        </div>

                        <!-- Hero Meta -->
                        <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">

                            <!-- Account -->
                            
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Breadcumb Area -->
    <div class="breadcumb_area">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <h5>Login &amp; Registrazione</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area -->

    <!-- Login Area -->
    <div class="bigshop_reg_log_area section_padding_100_50">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="login_form mb-50">
                        <h5 class="mb-3">Login</h5>

                        <form action="utenti/login.php" method="POST">
                            <div class="form-group">
                                <input type="email" class="form-control" name="emailLOG" id="username" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="passLOG" id="password" placeholder="Password">
                            </div>
                             <!-- 
                            <div class="form-check">
                                <div class="custom-control custom-checkbox mb-3 pl-1">
                                    <input type="checkbox" class="custom-control-input" id="customChe">
                                    <label class="custom-control-label" for="customChe">Ricorda questo dispositivo</label>
                                </div>
                            </div>
                            -->
                            <button type="submit" class="btn btn-primary btn-sm">Login</button>
                        </form>
                        <!-- Forget Password -->
                        <div class="forget_pass mt-15">
                            <a href="./password_dimenticata.php">Password dimenticata?</a>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-6">
                    <div class="login_form mb-50">
                        <h5 class="mb-3">Registrazione</h5>

                        <form action="utenti/insert.php" method="post">
                            <div class="form-group">
                                <input type="text" name="nome" class="form-control" id="username" placeholder="Nome" required>
                            </div>
                            <div class="form-group">
                                <input type="text" name="cognome" class="form-control" id="username" placeholder="Cognome" required>
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" class="form-control" id="username" placeholder="Email" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="pass1" class="form-control" id="password1" placeholder="Password" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="pass2" class="form-control" onchange="check_regi('password1','password2')" id="password2" placeholder="Repeat Password" required>
                            </div>
                            <div class="form-group">
                                <input type="tel"  name="numero" class="form-control" id="username" placeholder="Numero di telefono" required>
                            </div>
                            <p id="contr" style="display: none;" >sas</p> <br>
                            <button type="submit" id="submit" class="btn btn-primary btn-sm">Registrazione</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Login Area End -->

    <br>

    <!-- Footer Area -->
    <footer class="footer_area">
        <div class="container section_padding_50_0">
            <div class="row">

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6> - Navigazione - </h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="index.php"><i class="icofont-rounded-right"></i> Home <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="carrello.php"><i class="icofont-rounded-right"></i> Carrello <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="about-us.php"><i class="icofont-rounded-right"></i> About us <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6>- Catalogo -</h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="catalogo-dolce-1.php"><i class="icofont-rounded-right"></i> Dolce <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="catalogo-salato-1.php"><i class="icofont-rounded-right"></i> Salato <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="catalogo-bevande-1.php"><i class="icofont-rounded-right"></i> Bevande <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer_bottom_area">
            <div class="container">
                <div class="row align-items-center">
                    <!-- Copywrite -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite_text">
                            <p>Made with <i class="fa fa-heart" aria-hidden="true"></i> by Flore, Mari, Safi, Dedo, Botto</p>
                            <p>Progetto scolastico di: I.I.S. A. Avogadro di Torino</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/default/classy-nav.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/default/scrollup.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jarallax.min.js"></script>
    <script src="js/jarallax-video.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/default/active.js"></script>


    <script>
    
    function check_regi(id1,id2){

        var element1 = document.getElementById(id1);
        var value1 = element1.value;


        var element2 = document.getElementById(id2);
        var value2 = element2.value;

        var element3 = document.getElementById("contr");
        var show = element3.value;



        if (value1 == value2) {
            element3.style.display = 'block';
            element3.innerHTML = 'password uguali!';
            element3.style.color = "green";

            var element4 = document.getElementById("submit");
                element4.disabled = false;
                element4.innerHTML = 'Registrazione';

        } else {
            
            element3.style.display = 'block';
            element3.innerHTML = 'password non uguali!';
            
            element3.style.color = "red";
            var element4 = document.getElementById("submit");
                element4.disabled = true;
                element4.innerHTML = 'Per registrarti devi inserire le password uguali';
        }


    }
    
    
    
    </script>



</body>

</html>