<?php
        //viene fatto il session unset per dimenticare tutte le informazioni dell'utente e quindi fargli fare il logout
        if (session_status() === PHP_SESSION_NONE){
            session_start();
          }

    session_unset();
    header("Refresh: 0 , url=../login.php");

?>