<?php
//dato che si deve creare un carrello molto spesso, si utilizza una pagina apposita che verrà inclusa
if (session_status() === PHP_SESSION_NONE){
  session_start();
}

$sql = "INSERT INTO carrello (`id`,`id_utente`) VALUES (NULL,".$_SESSION["id"].")"; //inserimento del carrello all'interno della tabella carrello
              
              //Notice: Undefined index: id in C:\xampp\htdocs\Gianni-Express\file\utenti\insert.php on line 57

              if ($conn->query($sql)) {

                $message = "Ora sei un nostro utente";
               // echo "<script type='text/javascript'>alert('$message');</script>";

              }
            
              $id_carrello= $conn->insert_id;
              $_SESSION["id_carrello"]=$id_carrello;
             
?>