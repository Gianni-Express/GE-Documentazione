<?php
                                           
                                           if (session_status() === PHP_SESSION_NONE){
                                            session_start();
                                          }
//viene confermato l'utente cosi da fargli accedere a tutto
include '../database/connessione.php';


                $id = $_GET["id"];

        $sql1 = "UPDATE users SET verificato='1'WHERE id=".$id;

            if ($result = $conn->query($sql1)) {
            echo "Record updated successfully";
            header("Refresh: 0 , url=../login.php");
            } else {
            echo "Error updating record: " . $conn->error;
            }

            $conn->close();

            

            
      


?>