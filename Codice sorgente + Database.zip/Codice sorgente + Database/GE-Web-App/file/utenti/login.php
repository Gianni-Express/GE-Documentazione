<?php
session_start();?>
<!doctype html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title  -->
    <title>Gianni Express</title>

    <!-- Favicon  -->
    <link rel="icon" href="../img/galleria/logo.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="../style.css">

</head>

<body>

    <!-- Not Found Area -->
    <section class="error_page text-center section_padding_100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-6">
                    <div class="not-found-text">
                        <br><br>
                        <h3 class="mb-3">

                        <?php
                         // session_cache_expire(10);
                           

                          include '../database/connessione.php';

                          $sql = "SELECT users.verificato, users.id,users.pass,users.role,users.email,carrello.id as id_carrello FROM users,carrello where carrello.ordinato = 0 and users.id = carrello.id_utente";
                          $result = $conn->query($sql);




                          $flag=false;
                          if ($result->num_rows > 0) {
                            // output data of each row

                              

                            while($row = $result->fetch_assoc()) {


                              $salt = "SSERPXEINNAIG";


                              if ($row["email"] == $_REQUEST["emailLOG"] && $row["pass"] ==  crypt($_REQUEST["passLOG"],$salt)) {
                                    
                                  if ($row["verificato"] == 1) {

                                    //verranno salvate tutte le informazioni dell'utente nelle sessioni cosi da poterle raggiungere da tutte le pagine
                                  $_SESSION["id"] = $row["id"];
                                  $_SESSION["email"] = $row["email"];
                                  $_SESSION["pass"] = $row["pass"];
                                  $_SESSION["id_carrello"] = $row["id_carrello"];
                                  $_SESSION["loggato"] = true;

                                    
                                    if ($row["role"] == "s" || $row["role"] == "a") {
                                      $_SESSION["role"] = $row["role"];
                                      //echo "admin";
                                      header("Refresh: 0, url=../admin/super_admin.php");
                                    
                                    } else {
                                      //echo "users";

                                      $_SESSION["role"] = $row["role"];
                                      

                                    header("Refresh: 0, url=../index.php");
                                    
                                    }

                                  $flag=true;
                                  
                                
                                } else {
                                    $message = "devi prima confermare l'account <br><br><br>";
                                    echo $message;
                                  }
                                  

                                     
                                  
                                }
                            }

                              if ($flag==false) { //se non esistono uteti con quella email e password viene detto che 
                                                  //l'email o la password non sono corretti, si include anche il fatto che forse non si
                                                  //è registrati con quella email 
                                  echo "Passoword o email errati";
                                  header("Refresh: 3 , url=../login.php");
                              }
 
                          } else {
                            echo "Errore, contattare gli admin del sito";
                            header("Refresh: 3 , url=../login.php");
                          }

                        ?>

                        </h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Not Found Area End -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/default/classy-nav.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/default/scrollup.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jarallax.min.js"></script>
    <script src="js/jarallax-video.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/default/active.js"></script>

</body>

</html>
