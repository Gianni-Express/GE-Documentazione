﻿ <?php                           if (session_status() === PHP_SESSION_NONE){
                            session_start();
                          }?> <!doctype html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title  -->
    <title>Gianni Express</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/galleria/logo.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
<?php                            
//echo $_SESSION["id"];
?>
    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner-grow" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    

    <div class="shortcodes_area section_padding_100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="shortcodes_title mb-30">
                        <h4>Informazioni sul prodotto</h4>
                    </div>
                    <div class="shortcodes_content">
                        <div class="table-responsive">

                            
                        <?php


include 'database/connessione.php';
$sql = "SELECT nome,ID,energia from prodotti where ID=".$_GET["id"];

                $result = $conn->query($sql);
                $raw = $result->fetch_assoc();

echo "
<table class='table mb-0 table-bordered'>
    <thead>
        <tr>
            <th scope='col'>#".$raw['ID']."</th>
            <th scope='col'>".$raw['nome']."</th>
        </tr>
    </thead>
    <tbody>";









$sql = "SELECT pi.id_prod, GROUP_CONCAT(i.nome SEPARATOR ',') as ins
FROM ingredienti i, prodotti_ingredienti pi
where pi.id_prod=".$_GET["id"]." and pi.id_ingrediente = i.id 
GROUP BY pi.id_prod";


                $result = $conn->query($sql);

                if($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    echo "
                    
                    
                            <tr>
                                <th scope='row'>Ingredienti</th>
                                <td>".$row['ins']."</td>
                            </tr>";
                }


    

        $sql = "SELECT GROUP_CONCAT(a.allergeno SEPARATOR ',<br> ') as alle 
        FROM  allergeni a";
        
                        $result = $conn->query($sql);
                        $row = $result->fetch_assoc();
        echo $conn->error;
        
        echo "
                <tr>
                    <th scope='row'>Possibili allergeni</th>
                    <td>".$row['alle']."</td>
                </tr>
                <tr>
                    <th scope='row'>Valori nutrizionali</th>
                    <td>".$raw['energia']." kcal</td>
                </tr>
            </tbody>
        </table>";


?>












                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/default/classy-nav.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/default/scrollup.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jarallax.min.js"></script>
    <script src="js/jarallax-video.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/default/active.js"></script>

</body>

</html>