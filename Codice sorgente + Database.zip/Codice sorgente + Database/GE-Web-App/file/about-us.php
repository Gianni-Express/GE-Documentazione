﻿ <?php                           if (session_status() === PHP_SESSION_NONE){ //controllo, evita errori session already started
                            session_start(); //avvia sessione
                          }?> <!doctype html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title  -->
    <title>Gianni Express</title>

    <!-- Favicon  -->
      <link rel="icon" href="img/galleria/logo.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>

    <?php                            
    //echo $_SESSION["id"];
    ?>

    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner-grow" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <!-- Header Area -->
    <header class="header_area">

        <!-- Main Menu -->
        <div class="bigshop-main-menu">
            <div class="container">
                <div class="classy-nav-container breakpoint-off">
                    <nav class="classy-navbar" id="bigshopNav">

                        <!-- Nav Brand -->
                        <a href="index.php" class="nav-brand"><img style="width: 50px;height: 50px;" src="img/galleria/logo.png" alt="logo"></a>

                        <!-- Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">
                            <!-- Close -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="#">Catalogo</a>
                                        <ul class="dropdown">
                                            <li><a href="catalogo-dolce-1.php">Dolce</a></li>
                                            <li><a href="catalogo-salato-1.php">Salato</a></li>
                                            <li><a href="catalogo-bevande-1.php">Bevande</a></li>
                                        </ul>
                                    </li>
                                    
                                    <?php if(isset($_SESSION["id"])){ //utente loggato quindi si deve mostrare la sezione del carrello?> 
                                        <li><a href="carrello.php">Carrello</a></li>
                                    <?php } ?>

                                    <li><a href="about-us.php">About us</a></li>
                                </ul>
                            </div>

                        </div>




                        <?php if(isset($_SESSION["id"])){ //utente loggato quindi serve mostrare il riquado dell'utente?>
                            <!-- Hero Meta -->
                            <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">
                                <!-- Account -->
                                <div class="account-area">
                                    <div class="user-thumbnail">
                                        <a href="my-account.php"><img src="img/galleria/user1.jpg" alt=""></a>
                                        <!-- <img src="img/galleria/user1.jpg" alt=""> -->
                                    </div>
                                    <ul class="user-meta-dropdown">
                                        <li class="user-title"><span>Salve,</span>
                                            <?php
                                                include 'database/connessione.php'; //viene incluso la connessione al db
                                                $sql = "SELECT * FROM users WHERE id=".$_SESSION['id'].""; //selezione dati utente
                                                $result = $conn->query($sql);
                                                    if ($result) {
                                                        $row = $result->fetch_assoc();
                                                        echo $row["nome"]." ".$row["cognome"];
                                                    }else{
                                                        echo $conn->error; 
                                                        echo '0';
                                                    }
                                            ?>
                                        </li>
                                        <li><a href="utenti/logout.php"><i class="icofont-logout"></i> Logout</a></li>
                                    </ul>
                                </div>
                            </div>
                        <?php }else{ //nel caso non si loggato si stampa il pulsante che ti porta al login?>
                            <!-- Hero Meta -->
                            <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">
                                <a href="login.php" class="btn btn-dark mb-1">LOGIN</a>
                            </div>
                        <?php } ?>


                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Breadcumb Area -->
    <div class="breadcumb_area">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <h5>About Us</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area -->

    <!-- About Us Area -->
    <section class="about_us_area section_padding_100">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-lg-6">
                    <div class="about_us_content pb-5 pb-lg-0">
                        <div class="row">
                            <div class="col-6">
                                <img src="img/galleria/cornetto_bello.jpg" alt="">
                            </div>
                            <div class="col-6">
                                <img src="img/galleria/bar.jpg" alt="">
                            </div>
                            <div class="col-6">
                                <img src="img/galleria/bar.jpg" alt="">
                            </div>
                            <div class="col-6">
                                <img src="img/galleria/cornetto_bello.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="about_us_content pl-0 pl-lg-5">
                        <h5>In questa sezione caricheremo la documentazione relativa al progetto.</h5>
                        <br>
                        <p>Relazione tecnica della web-app --> <a href="documenti/relazione.pdf" target="_blank">Apri file</a></p>
                        <p>Documento di gestione del progetto --> <a href="documenti/gestione.pdf" target="_blank">Apri file</a></p>
                        <p>Il nostro progetto su GitHub --> <a href="https://github.com/Gianni-Express" target="_blank">Visita</a></p>
                        <p>Potete contattarci all'indirizzo: <a href="mailto:gianni.express@itisavogadro.it">gianni.express@itisavogadro.it</a><strong></strong></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About Us Area -->

    <!-- Cool Facts Area -->
    <section class="about_us_one cool_facts_area section_padding_100_70 bg-overlay jarallax" style="background-image: url(img/galleria/bar.jpg);">
        <div class="container">
            <div class="row">
                <br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>
            </div>
        </div>
    </section>
    <!-- Cool Facts Area End -->

    <!-- Testimonial Area -->
    <section class="testimonials_area bg-gray section_padding_100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-6">
                    <div class="popular_section_heading mb-50 text-center">
                        <h5 class="mb-3">Partecipanti al progettto "Gianni Express"</h5>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-8">
                    <div class="testimonials_slides owl-carousel">

                        <div class="single_tes_slide text-center">
                            <img src="img/galleria/flore.jpg" alt="">
                            <h6>Dario Florenzano</h6>
                        </div>

                        <div class="single_tes_slide text-center">
                            <img src="img/galleria/mari.jpg" alt="">
                            <h6>Alessandro Marinari</h6>
                        </div>

                        <div class="single_tes_slide text-center">
                            <img src="img/galleria/safi.jpg" alt="">
                            <h6>Safia Mandarun</h6>
                        </div>

                        <div class="single_tes_slide text-center">
                            <img src="img/galleria/botto.jpg" alt="">
                            <h6>Riccardo Botto</h6>
                        </div>

                        <div class="single_tes_slide text-center">
                            <img src="img/galleria/edo.jpg" alt="">
                            <h6>Edoardo Mateoiu</h6>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonial Area End -->

    <!-- Footer Area -->
    <footer class="footer_area">
        <div class="container section_padding_50_0">
            <div class="row">

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6> - Navigazione - </h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="index.php"><i class="icofont-rounded-right"></i> Home <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="carrello.php"><i class="icofont-rounded-right"></i> Carrello <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="about-us.php"><i class="icofont-rounded-right"></i> About us <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>

                <!-- Single Footer Area -->
                <div class="col-12 col-sm-6 col-md col-lg-4 col-xl-2">
                    <div class="single_footer_area mb-50 ml-5">
                        <div class="footer_heading mb-4">
                            <h6>- Catalogo -</h6>
                        </div>
                        <ul class="footer_widget_menu">
                            <li><a href="catalogo-dolce-1.php"><i class="icofont-rounded-right"></i> Dolce <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="catalogo-salato-1.php"><i class="icofont-rounded-right"></i> Salato <i class="icofont-rounded-left"></i></a></li>
                            <li><a href="catalogo-bevande-1.php"><i class="icofont-rounded-right"></i> Bevande <i class="icofont-rounded-left"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer_bottom_area">
            <div class="container">
                <div class="row align-items-center">
                    <!-- Copywrite -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite_text">
                            <p>Made with <i class="fa fa-heart" aria-hidden="true"></i> by Flore, Mari, Safi, Dedo, Botto</p>
                            <p>Progetto scolastico di: I.I.S. A. Avogadro di Torino</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/default/classy-nav.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/default/scrollup.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jarallax.min.js"></script>
    <script src="js/jarallax-video.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/default/active.js"></script>

</body>

</html>