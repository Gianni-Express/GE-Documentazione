<?php
session_start();
phpinfo();
?>