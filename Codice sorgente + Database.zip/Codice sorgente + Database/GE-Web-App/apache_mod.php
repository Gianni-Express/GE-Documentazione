
<?php
//print_r(apache_get_modules());
//phpinfo();
echo session_status()."<br>";
if (session_status() !=2) {
    echo "session_start()";
    session_start();
}
//
print_r($_SESSION);
?>

    